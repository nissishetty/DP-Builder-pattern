package com.cts.builderpattern;

public interface Packing {

	public String pack();

}